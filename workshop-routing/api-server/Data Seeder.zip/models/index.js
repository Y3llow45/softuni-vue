module.exports = {
    User: require('./user'),
    Tutorial: require('./tutorial')
};